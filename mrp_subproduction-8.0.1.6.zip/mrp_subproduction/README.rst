MRP Subproduction
=================

This module allows to assign production orders to another parent production
order, showing how many of the parent product was consumed in each of its children production orders.