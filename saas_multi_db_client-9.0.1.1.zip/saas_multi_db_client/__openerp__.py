{
    'name': "SAAS Multi Database Client",
    'version': "1.1",
    'author': "Vuente",
    'category': "Tools",
    'summary':'Adds special saas user which is designed to be used with saas_multi_db',
    'license':'LGPL-3',
    'data': [
        'data/res.users.csv',
    ],
    'demo': [],
    'images':[
        'static/description/1.jpg',
    ],
    'depends': [],
    'installable': True,
}