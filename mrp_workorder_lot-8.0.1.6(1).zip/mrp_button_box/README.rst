MRP Button Box
==============

Dummy module to add a button box at the manufacturing order right uper corner.
This module can be find at lp:addons-vauxoo/7.0/mrp_button_box