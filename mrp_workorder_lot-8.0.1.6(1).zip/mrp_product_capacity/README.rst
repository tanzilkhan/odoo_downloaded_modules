MRP Product Capacity
====================

TODO: Add module description
