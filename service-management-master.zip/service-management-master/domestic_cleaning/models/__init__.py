import res_partner
import crm_lead
import calendar_service
import analytic
import crm_claim
import hr