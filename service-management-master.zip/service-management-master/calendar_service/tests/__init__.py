from . import test_calendar_methods
from . import test_service

fast_suite = [
    test_calendar_methods,
    test_service,
]