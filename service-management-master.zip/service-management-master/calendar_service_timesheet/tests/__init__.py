from . import test_timesheet

fast_suite = [
    test_timesheet,
]