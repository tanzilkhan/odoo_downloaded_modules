## **Odoo v8.0 HR - Loans Management** ##

Fully integrated with Accounting and Analytic Accounting Modules.

Follow the standard Payroll module workflow.

Features:

* Manage your employees loans and settlement deductions.
* Define loan amount, Settlement amounts, Settlement periods, Payment methods and More.
* Define payment Methods Name, Journal, Debit, Credit Accounts and Analytic Account.
* Create your restriction of maximum loan percentage amount of salary.
* Arabic translation.

Contributed By [Smart Way Business Solutions](http://smartway-jo.com/)