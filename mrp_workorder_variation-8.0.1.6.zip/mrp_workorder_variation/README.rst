MRP WorkOrder Variation
=======================

Lets have a detailed control of the number of products in and out in a work order. That is,
this module adds a table in the work orders with the real products that are received and outgoing.
In this way the user can make a comparison of the variation of quantities and avoid loss of
material.