.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: AGPLv3 License

Remove odoo.com bindings on website
===================================

This module remove odoo.com bindings on website:

* Remove "Create a free website with Odoo" from footer

Credits
=======

Contributors
------------

* Antonio Espinosa <antonioea@antiun.com>

Maintainer
----------

.. image:: http://www.antiun.com/images/logo.png
   :alt: Antiun Ingeniería S.L.
   :target: http://www.antiun.com

This module is maintained by Antiun Ingeniería S.L.

Antiun Ingeniería S.L. is an IT consulting company especialized in Odoo
and provides Odoo development, install, maintenance and hosting
services.

To contribute to this module, please visit https://github.com/Antiun
or contact us at comercial@antiun.com

