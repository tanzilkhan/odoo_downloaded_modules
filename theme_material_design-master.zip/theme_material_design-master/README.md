theme_material_design
=====================

<h1>Currently a work in progress - not installable</h1>

Odoo Bootstrap Material Design Boilerplate Theme Module (Website)

This module aims to build a frontend theme based on the Google's material design concept and FezVrasta's bootstrap html template (https://github.com/FezVrasta/bootstrap-material-design) to help kickstart your Odoo theme module development. This will aim to remove the dependencies on the bootstrap framework to free up developers to use other platforms.
