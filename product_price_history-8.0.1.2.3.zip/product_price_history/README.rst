Product Price History
=====================

This module allows you to:

* Record various prices of the same product for different companies. This
  way, every company can have its own costs (average or standard) and
  sale prices.
* Historize the prices in a way that you'll then be able to retrieve the
  cost price at a given date.

Contributors
------------

* Joël Grand-Guillaume <joel.grand-guillaume@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Pedro M. Baeza <pedro.baeza@serviciobaeza.com> (Migration to v8 new API)
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>