Product Variant Cost
====================
This module adds a new cost field in product variant.
Updates the product variant's cost when product template cost is updated.
Adds a new inventory field on quants, (product variant cost * quant quantity).
New proceeding on the instalation of the module to load the product template's cost in the new field of product variant.


Credits
=======

Contributors
------------

* Ainara Galdona <ainaragaldona@avanzosc.es>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>

