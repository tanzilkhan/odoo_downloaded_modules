#-*- coding:utf-8 -*-

{
    'name': 'Employee Shift Scheduling Extended',
    'version': '1.0',
    'author': 'Tanzil Khan',
    'category': 'Generic Modules/Human Resources',
    'data': [
        'views/hr_schedule_extended_view_vt.xml'
    ],
    'depends': ['hr_schedule'],
    'installable': True,
    'active': False,
}
