from osv import fields, osv
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import time
from pytz import timezone,utc
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT as OE_DTFORMAT
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT as OE_DFORMAT


class hr_schedule_extended(osv.osv):
    _name = 'hr.schedule.extended'
    _description = 'Employee Schedule Extended'

    def _amount_all_one(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_one_total': 0.0,
            }

            val1=0
            val2=0
            hour_adjust = 0
            minute_adjust = 0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.satday_diff.split(':')[0])
                val2+=int(line.satday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_two(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_two_total': 0.0,
            }
            val1=0
            val2=0
            hour_adjust = 0
            minute_adjust = 0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.sunday_diff.split(':')[0])
                val2+=int(line.sunday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_three(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_three_total': 0.0,
            }
            val1=0
            val2=0
            hour_adjust = 0
            minute_adjust = 0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.monday_diff.split(':')[0])
                val2+=int(line.monday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_four(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_four_total': 0.0,
            }
            val1=0
            val2=0
            hour_adjust = 0
            minute_adjust = 0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.tuesday_diff.split(':')[0])
                val2+=int(line.tuesday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_five(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_five_total': 0.0,
            }
            val1=0
            val2=0
            hour_adjust = 0
            minute_adjust = 0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.wednesday_diff.split(':')[0])
                val2+=int(line.wednesday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_six(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_six_total': 0.0,
            }
            val1=0
            val2=0
            hour_adjust = 0
            minute_adjust = 0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.thursday_diff.split(':')[0])
                val2+=int(line.thursday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_seven(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_seven_total': 0.0,
            }
            val1=0
            val2=0
            hour_adjust = 0
            minute_adjust = 0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.friday_diff.split(':')[0])
                val2+=int(line.friday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res


    def _get_lines_one(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_two(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_three(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_four(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_five(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_six(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_seven(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()


    _columns = {
        'department_id': fields.many2one('hr.department', 'Department Name', required=True,),
        'company_id': fields.many2one('res.company', 'Company',),
        'employee_id': fields.many2one('hr.employee', 'Employee',),
        'template_id': fields.char('Schedule Template', ),
        'date_start': fields.date('Start Date', required=True,),
        'date_end': fields.date('End Date', required=True, ),
        'name': fields.char("Description", size=64, required=True,),
        'sche_summary': fields.one2many('sche.summary', 'sch_rel', 'Work Summary',),

        'day_one_total': fields.function(_amount_all_one, string='Saturday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_one, ['satday_diff'], 10),
            },
            help="Saturday sum"),

        'day_two_total': fields.function(_amount_all_two, string='Sunday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_two, ['sunday_diff'], 10),
            },
            help="Sunday sum"),

        'day_three_total': fields.function(_amount_all_three, string='Monday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_three, ['monday_diff'], 10),
            },
            help="Monday sum"),

        'day_four_total': fields.function(_amount_all_four, string='Tuesday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_four, ['tuesday_diff'], 10),
            },
            help="Tuesday sum"),

        'day_five_total': fields.function(_amount_all_five, string='Wednesday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_five, ['wednesday_diff'], 10),
            },
            help="Wednesday sum"),

        'day_six_total': fields.function(_amount_all_six, string='Thursday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_six, ['thursday_diff'], 10),
            },
            help="Thursday sum"),

        'day_seven_total': fields.function(_amount_all_seven, string='Friday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_seven, ['friday_diff'], 10),
            },
            help="Friday sum"),
    }

    _defaults = {
        # 'company_id': lambda self, cr, uid, context: self.pool.get('res.company')._company_default_get(cr, uid, 'hr.schedule.extended', context=context),
        # 'state': 'draft',
    }

    def onchange_employee_start_date(self, cr, uid, ids, date_start, context=None):

        res = {'value': {
            }}

        if date_start:
            dStart = datetime.strptime(date_start, '%Y-%m-%d').date()
            # The schedule must start on a Monday
            if dStart.weekday() != 0:
                res['value']['date_start'] = False
                res['value']['date_end'] = False
            else:
                dEnd = dStart + relativedelta(days=+6)
                res['value']['date_end'] = dEnd.strftime('%Y-%m-%d')


        return res

    def create(self, cr, uid, values, context=None):
        if not values['sche_summary']:
            return super(hr_schedule_extended, self).create(cr, uid, values, context=context)
        else:
            # a= values['sche_summary'][0][2]
            for i in values['sche_summary']:
                end_date=datetime.strptime(values['date_end'],'%Y-%m-%d').date()
                start_date=datetime.strptime(values['date_start'],'%Y-%m-%d').date()
                employee_name=self.pool.get('hr.employee').browse(cr,uid,i[2]['employee_name'],context=context).name

                time_line=[]

                date_limit=start_date
                date_with_time_start=None
                date_with_time_end=None
                while date_limit<=end_date:
                    day_of_week=date_limit.weekday()

                    if day_of_week==0:
                        date_with_time_start= str(date_limit)+' '+i[2]['monday_one'].split('-')[0]+':00'
                        date_with_time_end= str(date_limit)+' '+i[2]['monday_one'].split('-')[1]+':00'

                    elif day_of_week==1:
                        date_with_time_start= str(date_limit)+' '+i[2]['tuesday_one'].split('-')[0]+':00'
                        date_with_time_end= str(date_limit)+' '+i[2]['tuesday_one'].split('-')[1]+':00'

                    elif day_of_week==2:
                        date_with_time_start= str(date_limit)+' '+i[2]['wednesday_one'].split('-')[0]+':00'
                        date_with_time_end= str(date_limit)+' '+i[2]['wednesday_one'].split('-')[1]+':00'
                    elif day_of_week==3:
                        date_with_time_start= str(date_limit)+' '+i[2]['thursday_one'].split('-')[0]+':00'
                        date_with_time_end= str(date_limit)+' '+i[2]['thursday_one'].split('-')[1]+':00'
                    elif day_of_week==4:
                        date_with_time_start= str(date_limit)+' '+i[2]['friday_one'].split('-')[0]+':00'
                        date_with_time_end= str(date_limit)+' '+i[2]['friday_one'].split('-')[1]+':00'
                    elif day_of_week==5:
                        date_with_time_start= str(date_limit)+' '+i[2]['satday_one'].split('-')[0]+':00'
                        date_with_time_end= str(date_limit)+' '+i[2]['satday_one'].split('-')[1]+':00'
                    elif day_of_week==6:
                        date_with_time_start= str(date_limit)+' '+i[2]['sunday_one'].split('-')[0]+':00'
                        date_with_time_end= str(date_limit)+' '+i[2]['sunday_one'].split('-')[1]+':00'


                    user = self.pool.get('res.users').browse(
                        cr, uid, uid, context=context)

                    local_tz = timezone(user.tz)

                    dwts=datetime.strptime(date_with_time_start, "%Y-%m-%d %H:%M:%S")
                    dwte=datetime.strptime(date_with_time_end,"%Y-%m-%d %H:%M:%S")

                    locldtStart = local_tz.localize(dwts, is_dst=False)
                    locldtEnd = local_tz.localize(dwte, is_dst=False)

                    utcdtStart = locldtStart.astimezone(utc)
                    utcdtStart=utcdtStart.strftime("%Y-%m-%d %H:%M:%S")
                    utcdtEnd = locldtEnd.astimezone(utc)
                    utcdtEnd=utcdtEnd.strftime("%Y-%m-%d %H:%M:%S")

                    # dtStart = datetime.strptime(date_with_time_start, OE_DTFORMAT)
                    # dtEnd=datetime.strptime(date_with_time_end, OE_DTFORMAT)

                    # dwts = utcdtStart.astimezone(local_tz).datetime()
                    # dwts=datetime.strptime(str(dwts), "%Y-%m-%d %H:%M:%S")
                    #
                    # dwte = utcdtEnd.astimezone(local_tz).datetime()
                    # dwte=datetime.strptime(str(dwte),"%Y-%m-%d %H:%M:%S")







                    time_line.append([0, False, {'dayofweek': str(day_of_week), 'date_end': str(utcdtEnd),
                                                 'date_start': str(utcdtStart), 'name': values['name']}])
                    date_limit+=timedelta(days=1)

                # for every day till end date find weekday name pick time value of
                #that weekday and make datetime from that

                vals={'restday_ids1': [[6, False, []]],
                      'restday_ids3': [[6, False, []]],
                      'employee_id': i[2]['employee_name'],
                      'restday_ids5': [[6, False, []]],
                      'name': employee_name,
                      'date_end': end_date,
                      'date_start': start_date,
                      'detail_ids': time_line,
                      'restday_ids2': [[6, False, []]],
                      'template_id': values['template_id'],
                      'restday_ids4': [[6, False, []]]}

                self.pool.get('hr.schedule').create(cr,uid,vals,context=context)
            return super(hr_schedule_extended, self).create(cr, uid, values, context=context)

    def write(self, cr, uid, ids, values, context=None):
        for j in self.browse(cr,uid,ids,context=context):
            date_start=j.date_start
            date_end=j.date_end
        if values.get('sche_summary') is not None:
            sch_detail_obj=self.pool.get('hr.schedule.detail')
            for i in values['sche_summary']:
                if i[2] is not False and i[1] is not False:
                    new_date_start=str(date_start)+' '+'00:00:00'
                    new_date_end=str(date_end)+' '+'00:00:00'

                    employee_id=self.pool.get('sche.summary').read(cr,uid,i[1],['employee_name'],context=context)
                    emp_id=employee_id['employee_name'][0]
                    if 'monday_one' in i[2].keys():

                        cr.execute("""SELECT t2.id FROM hr_schedule AS t1
                                      JOIN hr_schedule_detail AS t2
                                      ON t1.id=t2.schedule_id
                                      WHERE t2.date_start BETWEEN
                                      %s::date
                                      AND %s::date+1
                                      AND t1.employee_id=%s
                                      AND t2.dayofweek='0'""",(new_date_start,new_date_end,emp_id))
                        sch_detail_lines=cr.fetchall()
                        for k in sch_detail_lines:
                            if k is not None:
                                prev_dstart=sch_detail_obj.browse(cr,uid,k[0],context=context).date_start
                                date_value=prev_dstart.split(' ')[0]

                                user = self.pool.get('res.users').browse(
                                    cr, uid, uid, context=context)

                                local_tz = timezone(user.tz)


                                upd_start=date_value+' '+i[2]['monday_one'].split('-')[0]+':00'
                                upd_start=datetime.strptime(upd_start, "%Y-%m-%d %H:%M:%S")

                                upd_end=date_value+' '+i[2]['monday_one'].split('-')[1]+':00'
                                upd_end=datetime.strptime(upd_end, "%Y-%m-%d %H:%M:%S")

                                locldtStartEdit = local_tz.localize(upd_start, is_dst=False)
                                locldtEndEdit = local_tz.localize(upd_end, is_dst=False)

                                utcdtStartEdit = locldtStartEdit.astimezone(utc)
                                utcdtStartEdit=utcdtStartEdit.strftime("%Y-%m-%d %H:%M:%S")
                                utcdtEndEdit = locldtEndEdit.astimezone(utc)
                                utcdtEndEdit=utcdtEndEdit.strftime("%Y-%m-%d %H:%M:%S")

                                val_sch_detail={'date_start':utcdtStartEdit,'date_end':utcdtEndEdit}

                                sch_detail_obj.write(cr,uid,k[0],val_sch_detail,context=context)

                    if 'tuesday_one' in i[2].keys():
                        cr.execute("""SELECT t2.id FROM hr_schedule AS t1
                                      JOIN hr_schedule_detail AS t2
                                      ON t1.id=t2.schedule_id
                                      WHERE t2.date_start BETWEEN
                                      %s::date
                                      AND %s::date+1
                                      AND t1.employee_id=%s
                                      AND t2.dayofweek='1'""",(new_date_start,new_date_end,emp_id))
                        sch_detail_lines=cr.fetchall()
                        for k in sch_detail_lines:
                            if k is not None:
                                prev_dstart=sch_detail_obj.browse(cr,uid,k[0],context=context).date_start
                                date_value=prev_dstart.split(' ')[0]

                                user = self.pool.get('res.users').browse(
                                    cr, uid, uid, context=context)

                                local_tz = timezone(user.tz)

                                upd_start=date_value+' '+i[2]['tuesday_one'].split('-')[0]+':00'
                                upd_start=datetime.strptime(upd_start, "%Y-%m-%d %H:%M:%S")

                                upd_end=date_value+' '+i[2]['tuesday_one'].split('-')[1]+':00'
                                upd_end=datetime.strptime(upd_end, "%Y-%m-%d %H:%M:%S")

                                locldtStartEdit = local_tz.localize(upd_start, is_dst=False)
                                locldtEndEdit = local_tz.localize(upd_end, is_dst=False)

                                utcdtStartEdit = locldtStartEdit.astimezone(utc)
                                utcdtStartEdit=utcdtStartEdit.strftime("%Y-%m-%d %H:%M:%S")
                                utcdtEndEdit = locldtEndEdit.astimezone(utc)
                                utcdtEndEdit=utcdtEndEdit.strftime("%Y-%m-%d %H:%M:%S")

                                val_sch_detail={'date_start':utcdtStartEdit,'date_end':utcdtEndEdit}

                                sch_detail_obj.write(cr,uid,k[0],val_sch_detail,context=context)
                    if 'wednesday_one' in i[2].keys():

                        cr.execute("""SELECT t2.id FROM hr_schedule AS t1
                                      JOIN hr_schedule_detail AS t2
                                      ON t1.id=t2.schedule_id
                                      WHERE t2.date_start BETWEEN
                                      %s::date
                                      AND %s::date+1
                                      AND t1.employee_id=%s
                                      AND t2.dayofweek='2'""",(new_date_start,new_date_end,emp_id))
                        sch_detail_lines=cr.fetchall()
                        for k in sch_detail_lines:
                            if k is not None:
                                prev_dstart=sch_detail_obj.browse(cr,uid,k[0],context=context).date_start
                                date_value=prev_dstart.split(' ')[0]

                                user = self.pool.get('res.users').browse(
                                    cr, uid, uid, context=context)

                                local_tz = timezone(user.tz)

                                upd_start=date_value+' '+i[2]['wednesday_one'].split('-')[0]+':00'
                                upd_start=datetime.strptime(upd_start, "%Y-%m-%d %H:%M:%S")

                                upd_end=date_value+' '+i[2]['wednesday_one'].split('-')[1]+':00'
                                upd_end=datetime.strptime(upd_end, "%Y-%m-%d %H:%M:%S")

                                locldtStartEdit = local_tz.localize(upd_start, is_dst=False)
                                locldtEndEdit = local_tz.localize(upd_end, is_dst=False)

                                utcdtStartEdit = locldtStartEdit.astimezone(utc)
                                utcdtStartEdit=utcdtStartEdit.strftime("%Y-%m-%d %H:%M:%S")
                                utcdtEndEdit = locldtEndEdit.astimezone(utc)
                                utcdtEndEdit=utcdtEndEdit.strftime("%Y-%m-%d %H:%M:%S")

                                val_sch_detail={'date_start':utcdtStartEdit,'date_end':utcdtEndEdit}

                                sch_detail_obj.write(cr,uid,k[0],val_sch_detail,context=context)
                    if 'thursday_one' in i[2].keys():

                        cr.execute("""SELECT t2.id FROM hr_schedule AS t1
                                      JOIN hr_schedule_detail AS t2
                                      ON t1.id=t2.schedule_id
                                      WHERE t2.date_start BETWEEN
                                      %s::date
                                      AND %s::date+1
                                      AND t1.employee_id=%s
                                      AND t2.dayofweek='3'""",(new_date_start,new_date_end,emp_id))
                        sch_detail_lines=cr.fetchall()
                        for k in sch_detail_lines:
                            if k is not None:
                                prev_dstart=sch_detail_obj.browse(cr,uid,k[0],context=context).date_start
                                date_value=prev_dstart.split(' ')[0]

                                user = self.pool.get('res.users').browse(
                                    cr, uid, uid, context=context)

                                local_tz = timezone(user.tz)

                                upd_start=date_value+' '+i[2]['thursday_one'].split('-')[0]+':00'
                                upd_start=datetime.strptime(upd_start, "%Y-%m-%d %H:%M:%S")

                                upd_end=date_value+' '+i[2]['thursday_one'].split('-')[1]+':00'
                                upd_end=datetime.strptime(upd_end, "%Y-%m-%d %H:%M:%S")

                                locldtStartEdit = local_tz.localize(upd_start, is_dst=False)
                                locldtEndEdit = local_tz.localize(upd_end, is_dst=False)

                                utcdtStartEdit = locldtStartEdit.astimezone(utc)
                                utcdtStartEdit=utcdtStartEdit.strftime("%Y-%m-%d %H:%M:%S")
                                utcdtEndEdit = locldtEndEdit.astimezone(utc)
                                utcdtEndEdit=utcdtEndEdit.strftime("%Y-%m-%d %H:%M:%S")

                                val_sch_detail={'date_start':utcdtStartEdit,'date_end':utcdtEndEdit}

                                sch_detail_obj.write(cr,uid,k[0],val_sch_detail,context=context)
                    if 'friday_one' in i[2].keys():

                        cr.execute("""SELECT t2.id FROM hr_schedule AS t1
                                      JOIN hr_schedule_detail AS t2
                                      ON t1.id=t2.schedule_id
                                      WHERE t2.date_start BETWEEN
                                      %s::date
                                      AND %s::date+1
                                      AND t1.employee_id=%s
                                      AND t2.dayofweek='4'""",(new_date_start,new_date_end,emp_id))
                        sch_detail_lines=cr.fetchall()
                        for k in sch_detail_lines:
                            if k is not None:
                                prev_dstart=sch_detail_obj.browse(cr,uid,k[0],context=context).date_start
                                date_value=prev_dstart.split(' ')[0]

                                user = self.pool.get('res.users').browse(
                                    cr, uid, uid, context=context)

                                local_tz = timezone(user.tz)

                                upd_start=date_value+' '+i[2]['friday_one'].split('-')[0]+':00'
                                upd_start=datetime.strptime(upd_start, "%Y-%m-%d %H:%M:%S")

                                upd_end=date_value+' '+i[2]['friday_one'].split('-')[1]+':00'
                                upd_end=datetime.strptime(upd_end, "%Y-%m-%d %H:%M:%S")

                                locldtStartEdit = local_tz.localize(upd_start, is_dst=False)
                                locldtEndEdit = local_tz.localize(upd_end, is_dst=False)

                                utcdtStartEdit = locldtStartEdit.astimezone(utc)
                                utcdtStartEdit=utcdtStartEdit.strftime("%Y-%m-%d %H:%M:%S")
                                utcdtEndEdit = locldtEndEdit.astimezone(utc)
                                utcdtEndEdit=utcdtEndEdit.strftime("%Y-%m-%d %H:%M:%S")

                                val_sch_detail={'date_start':utcdtStartEdit,'date_end':utcdtEndEdit}

                                sch_detail_obj.write(cr,uid,k[0],val_sch_detail,context=context)
                    if 'satday_one' in i[2].keys():

                        cr.execute("""SELECT t2.id FROM hr_schedule AS t1
                                      JOIN hr_schedule_detail AS t2
                                      ON t1.id=t2.schedule_id
                                      WHERE t2.date_start BETWEEN
                                      %s::date
                                      AND %s::date+1
                                      AND t1.employee_id=%s
                                      AND t2.dayofweek='5'""",(new_date_start,new_date_end,emp_id))
                        sch_detail_lines=cr.fetchall()
                        for k in sch_detail_lines:
                            if k is not None:
                                prev_dstart=sch_detail_obj.browse(cr,uid,k[0],context=context).date_start
                                date_value=prev_dstart.split(' ')[0]

                                user = self.pool.get('res.users').browse(
                                    cr, uid, uid, context=context)

                                local_tz = timezone(user.tz)

                                upd_start=date_value+' '+i[2]['satday_one'].split('-')[0]+':00'
                                upd_start=datetime.strptime(upd_start, "%Y-%m-%d %H:%M:%S")

                                upd_end=date_value+' '+i[2]['satday_one'].split('-')[1]+':00'
                                upd_end=datetime.strptime(upd_end, "%Y-%m-%d %H:%M:%S")

                                locldtStartEdit = local_tz.localize(upd_start, is_dst=False)
                                locldtEndEdit = local_tz.localize(upd_end, is_dst=False)

                                utcdtStartEdit = locldtStartEdit.astimezone(utc)
                                utcdtStartEdit=utcdtStartEdit.strftime("%Y-%m-%d %H:%M:%S")
                                utcdtEndEdit = locldtEndEdit.astimezone(utc)
                                utcdtEndEdit=utcdtEndEdit.strftime("%Y-%m-%d %H:%M:%S")

                                val_sch_detail={'date_start':utcdtStartEdit,'date_end':utcdtEndEdit}

                                sch_detail_obj.write(cr,uid,k[0],val_sch_detail,context=context)

                    if 'sunday_one' in i[2].keys():

                        cr.execute("""SELECT t2.id FROM hr_schedule AS t1
                                      JOIN hr_schedule_detail AS t2
                                      ON t1.id=t2.schedule_id
                                      WHERE t2.date_start BETWEEN
                                      %s::date
                                      AND %s::date+1
                                      AND t1.employee_id=%s
                                      AND t2.dayofweek='6'""",(new_date_start,new_date_end,emp_id))
                        sch_detail_lines=cr.fetchall()
                        for k in sch_detail_lines:
                            if k is not None:
                                prev_dstart=sch_detail_obj.browse(cr,uid,k[0],context=context).date_start
                                date_value=prev_dstart.split(' ')[0]

                                user = self.pool.get('res.users').browse(
                                    cr, uid, uid, context=context)

                                local_tz = timezone(user.tz)

                                upd_start=date_value+' '+i[2]['sunday_one'].split('-')[0]+':00'
                                upd_start=datetime.strptime(upd_start, "%Y-%m-%d %H:%M:%S")

                                upd_end=date_value+' '+i[2]['sunday_one'].split('-')[1]+':00'
                                upd_end=datetime.strptime(upd_end, "%Y-%m-%d %H:%M:%S")

                                locldtStartEdit = local_tz.localize(upd_start, is_dst=False)
                                locldtEndEdit = local_tz.localize(upd_end, is_dst=False)

                                utcdtStartEdit = locldtStartEdit.astimezone(utc)
                                utcdtStartEdit=utcdtStartEdit.strftime("%Y-%m-%d %H:%M:%S")
                                utcdtEndEdit = locldtEndEdit.astimezone(utc)
                                utcdtEndEdit=utcdtEndEdit.strftime("%Y-%m-%d %H:%M:%S")

                                val_sch_detail={'date_start':utcdtStartEdit,'date_end':utcdtEndEdit}

                                sch_detail_obj.write(cr,uid,k[0],val_sch_detail,context=context)

        return super(hr_schedule_extended, self).write(cr, uid, ids, values, context=context)

    def unlink(self, cr, uid, ids, context=None):

        detail_obj = self.pool.get('sche.summary')

        if isinstance(ids, (int, long)):
            ids = [ids]

        schedule_ids = []
        for schedule in self.browse(cr, uid, ids, context=context):

            sche_summary = []
            [sche_summary.append(detail.id) for detail in schedule.sche_summary]
            if len(sche_summary) > 0:
                detail_obj.unlink(cr, uid, sche_summary, context=context)



        return super(hr_schedule_extended, self).unlink(cr, uid, ids, context=context)


class sche_summary(osv.osv):
    _name = 'sche.summary'
    _columns = {
        'sch_rel':fields.many2one('hr.schedule.extended', 'Schedule Lines', ondelete='cascade'),
        'name': fields.char('Schedule Summary'),
        'employee_name': fields.many2one('hr.employee', 'Employee Name'),

        'satday_one': fields.char('Saturday'),
        'satday_diff': fields.char('Sat Dif'),

        'sunday_one': fields.char('Sunday'),
        'sunday_diff': fields.char('Sun Dif'),

        'monday_one': fields.char('Monday'),
        'monday_diff': fields.char('Mon Dif'),

        'tuesday_one': fields.char('Tuesday'),
        'tuesday_diff': fields.char('tu Dif'),

        'wednesday_one': fields.char('Wednesday'),
        'wednesday_diff': fields.char('wed Dif'),

        'thursday_one': fields.char('Thursday'),
        'thursday_diff': fields.char('thurs Dif'),

        'friday_one': fields.char('Friday'),
        'friday_diff': fields.char('Fri Dif'),

        'total_diff': fields.char('Total'),

    }

    _defaults = {
        'satday_one': '00:00-00:00',
        'sunday_one': '00:00-00:00',
        'monday_one': '00:00-00:00',
        'tuesday_one': '00:00-00:00',
        'wednesday_one': '00:00-00:00',
        'thursday_one': '00:00-00:00',
        'friday_one': '00:00-00:00',

        'satday_diff': '0:0',
        'sunday_diff': '0:0',
        'monday_diff': '0:0',
        'tuesday_diff': '0:0',
        'wednesday_diff': '0:0',
        'thursday_diff': '0:0',
        'friday_diff': '0:0',
    }

    def onchange_saturday_date(self, cr, uid, ids, satday_one, context=None):
        result = {}
        time = satday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'satday_diff': the_diff}

        return result

    def onchange_sunday_date(self, cr, uid, ids, sunday_one, context=None):
        result = {}
        time = sunday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'sunday_diff': the_diff}

        return result

    def onchange_monday_date(self, cr, uid, ids, monday_one, context=None):
        result = {}
        time = monday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'monday_diff': the_diff}

        return result

    def onchange_tuesday_date(self, cr, uid, ids, tuesday_one, context=None):
        result = {}
        time = tuesday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'tuesday_diff': the_diff}

        return result

    def onchange_wednesday_date(self, cr, uid, ids, wednesday_one, context=None):
        result = {}
        time = wednesday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'wednesday_diff': the_diff}

        return result

    def onchange_thursday_date(self, cr, uid, ids, thursday_one, context=None):
        result = {}
        time = thursday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'thursday_diff': the_diff}

        return result

    def onchange_friday_date(self, cr, uid, ids, friday_one, context=None):
        result = {}
        time = friday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        if minute_diff<0:
            minute_diff = minute_diff + 60

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'friday_diff': the_diff}

        return result


    def onchange_total_calculation(self, cr, uid, ids, satday_diff, sunday_diff, monday_diff, tuesday_diff, wednesday_diff, thursday_diff, friday_diff, context=None):
        result = {}
        satday_v = satday_diff
        sunday_v = sunday_diff
        monday_v = monday_diff
        tuesday_v = tuesday_diff
        wednesday_v = wednesday_diff
        thursday_v = thursday_diff
        friday_v = friday_diff

        satday_hours = 0
        satday_minutes = 0
        if satday_v[1]==':':
            satday_hours= int(satday_v[0])
            satday_minutes = int(satday_v[2:])
        elif satday_v[2]==':':
            satday_hours = int(satday_v[:2])
            satday_minutes = int(satday_v[3:])

        sunday_hours = 0
        sunday_minutes = 0
        if sunday_v[1]==':':
            sunday_hours= int(sunday_v[0])
            sunday_minutes = int(sunday_v[2:])
        elif sunday_v[2]==':':
            sunday_hours = int(sunday_v[:2])
            sunday_minutes = int(sunday_v[3:])

        monday_hours = 0
        monday_minutes = 0
        if monday_v[1]==':':
            monday_hours= int(monday_v[0])
            monday_minutes = int(monday_v[2:])
        elif monday_v[2]==':':
            monday_hours = int(monday_v[:2])
            monday_minutes = int(monday_v[3:])

        tuesday_hours = 0
        tuesday_minutes = 0
        if tuesday_v[1]==':':
            tuesday_hours= int(tuesday_v[0])
            tuesday_minutes = int(tuesday_v[2:])
        elif tuesday_v[2]==':':
            tuesday_hours = int(tuesday_v[:2])
            tuesday_minutes = int(tuesday_v[3:])

        wednesday_hours = 0
        wednesday_minutes = 0
        if wednesday_v[1]==':':
            wednesday_hours= int(wednesday_v[0])
            wednesday_minutes = int(wednesday_v[2:])
        elif wednesday_v[2]==':':
            wednesday_hours = int(wednesday_v[:2])
            wednesday_minutes = int(wednesday_v[3:])

        thursday_hours = 0
        thursday_minutes = 0
        if thursday_v[1]==':':
            thursday_hours= int(thursday_v[0])
            thursday_minutes = int(thursday_v[2:])
        elif thursday_v[2]==':':
            thursday_hours = int(thursday_v[:2])
            thursday_minutes = int(thursday_v[3:])

        friday_hours = 0
        friday_minutes = 0
        if friday_v[1]==':':
            friday_hours= int(friday_v[0])
            friday_minutes = int(friday_v[2:])
        elif friday_v[2]==':':
            friday_hours = int(friday_v[0:2])
            friday_minutes = int(friday_v[3:5])

        total_hours = satday_hours + sunday_hours + monday_hours + tuesday_hours + wednesday_hours + thursday_hours + friday_hours

        total_minutes = satday_minutes + sunday_minutes + monday_minutes + tuesday_minutes + wednesday_minutes + thursday_minutes + friday_minutes

        hour_adjust = 0
        minute_adjust = 0
        if total_minutes > 60:
            minutes_precision = total_minutes/60
            minutes_fraction = total_minutes % 60
            hour_adjust = total_hours + abs(minutes_precision)
            minute_adjust = minutes_fraction
        elif total_minutes == 60:
            hour_adjust = total_hours + 1
            minute_adjust = 00
        else:
            hour_adjust = total_hours
            minute_adjust = total_minutes

        total_diff_calc = str(hour_adjust)+':'+str(minute_adjust)

        result['value'] = {'total_diff': total_diff_calc}

        return result

    def unlink(self, cr, uid, ids, context=None):
        detail_obj = self.pool.get('hr.schedule')

        if isinstance(ids, (int, long)):
            ids = [ids]

        schedule_ids = []
        for schedule in self.browse(cr, uid, ids, context=context):

            employee_id=schedule.employee_name.id

            sch_obj=self.pool.get('hr.schedule.extended')
            date_start=sch_obj.browse(cr,uid,schedule.sch_rel.id,context=context).date_start
            date_end=sch_obj.browse(cr,uid,schedule.sch_rel.id,context=context).date_end

            toBeDelIds=detail_obj.search(cr,uid,[('employee_id','=',employee_id),('date_start','=',date_start),('date_end','=',date_end)])

            detail_obj.unlink(cr,uid,toBeDelIds,context=context)

        return super(sche_summary, self).unlink(cr, uid, ids, context=context)

