# -*- coding: utf-8 -*-

import hr_schedule_extended_vt
