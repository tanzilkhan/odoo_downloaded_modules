from . import test_hr_contract_multi_jobs
