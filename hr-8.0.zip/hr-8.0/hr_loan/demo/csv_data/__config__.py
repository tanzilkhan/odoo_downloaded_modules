{'xml_files': [
    {'name': 'hr_loan',
     'depends': ['hr'],
     'csv':
     ['hr_loan.csv', ]},
]}
