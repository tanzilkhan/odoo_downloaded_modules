{
    'xml_files': [
        {
            'name': 'hr_loan',
            'depends': ['hr'],
            'csv': [
                'hr_salary_rule_category.csv',
                'hr_salary_rule.csv',
                'hr_payroll_structure.csv',
            ]
        },
    ]
}
