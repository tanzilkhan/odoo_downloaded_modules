# -*- coding: utf-8 -*-

from . import res_partner_bank
from . import account_bank_statement_import
from . import account_config_settings
