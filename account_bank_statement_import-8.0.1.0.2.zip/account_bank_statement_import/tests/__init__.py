# -*- encoding: utf-8 -*-
"""Define tests to be run."""
from . import test_res_partner_bank
from . import test_import_bank_statement
from .test_import_file import TestStatementFile
