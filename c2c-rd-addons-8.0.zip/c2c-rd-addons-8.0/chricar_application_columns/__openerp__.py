{ 'sequence': 500,
"name"         : "Application Columns"
, "version"      : "1.0"
, "author"       : "ChriCar Beteiligungs- und Beratungs- GmbH"
, "website"      : "http://www.chricar.at/ChriCar"
, "description"  : """Defines the Terp Columns
generated 2009-03-27 16:28:26+01"""
, "category"     : "Client Modules/Application"
, "depends"      : ["chricar_application_tables"]
, "init_xml"     : []
, "demo"         : []
, "data"   : ["application_columns_view.xml"]
, "auto_install" : False
, 'installable': False
, 'application'  : False
}

