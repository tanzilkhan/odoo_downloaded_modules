##############################################
#
# ChriCar Beteiligungs- und Beratungs- GmbH
# created 2009-03-27 16:28:26+01
##############################################
import application_columns

