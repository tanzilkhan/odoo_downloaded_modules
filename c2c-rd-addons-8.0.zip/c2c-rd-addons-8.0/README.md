[![Build Status](https://travis-ci.org/camptocamp/c2c-rd-addons.svg?branch=8.0)](https://travis-ci.org/camptocamp/c2c-rd-addons)
[![Coverage Status](https://coveralls.io/repos/camptocamp/c2c-rd-addons/badge.png?branch=8.0)](https://coveralls.io/r/camptocamp/c2c-rd-addons?branch=8.0)

Camptocamp R&D addons
=====================


Lots of things in there, which should progressively move to OCA.



