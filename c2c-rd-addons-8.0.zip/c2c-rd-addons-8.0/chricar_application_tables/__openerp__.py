{ 'sequence': 500,
"name"         : "Application Tables"
, "version"      : "1.0"
, "author"       : "ChriCar Beteiligungs- und Beratungs- GmbH"
, "website"      : "http://www.chricar.at/ChriCar"
, "description"  : """Defines the Terp Tabelle
generated 2009-03-27 16:17:42+01"""
, "category"     : "Client Modules/Application"
, "depends"      : ["base","chricar_application"]
, "init_xml"     : []
, "demo"         : []
, "data"   : ["application_tables_view.xml"]
, "auto_install" : False
, 'installable': False
, 'application'  : False
}

