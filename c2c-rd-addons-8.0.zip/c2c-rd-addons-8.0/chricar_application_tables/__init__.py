##############################################
#
# ChriCar Beteiligungs- und Beratungs- GmbH
# created 2009-03-27 16:17:42+01
##############################################
import application_tables

