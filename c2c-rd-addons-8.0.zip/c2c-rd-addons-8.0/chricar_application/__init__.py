##############################################
#
# ChriCar Beteiligungs- und Beratungs- GmbH
# created 2009-03-27 16:34:25+01
##############################################
import application

