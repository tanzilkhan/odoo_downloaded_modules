{ 'sequence': 500,
"name"         : "Application"
, "version"      : "1.0"
, "author"       : "ChriCar Beteiligungs- und Beratungs- GmbH"
, "website"      : "http://www.chricar.at/ChriCar"
, "description"  : """Defines the Application
generated 2009-03-27 16:34:25+01"""
, "category"     : "Client Modules/Application"
, "depends"      : ["base"]
, "init_xml"     : []
, "demo"         : []
, "data"   : ["application_view.xml"]
, "auto_install" : False
, 'installable': False
, 'application'  : False
}

