Fetchmail Corrections
=====================

This module correct some behaviours on Document and Fetchmail modules combinated.