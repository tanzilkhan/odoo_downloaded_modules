# coding: utf-8
{
    "name": "Fetchmail Corrections",
    "version": "0.6",
    "author": "Vauxoo",
    "category": "Tools",
    "website": "http://vauxoo.com",
    "license": "",
    "depends": [
        "fetchmail",
        "document"
    ],
    "demo": [],
    "data": [],
    "test": [],
    "js": [],
    "css": [],
    "qweb": [],
    "installable": True,
    "auto_install": False,
}
