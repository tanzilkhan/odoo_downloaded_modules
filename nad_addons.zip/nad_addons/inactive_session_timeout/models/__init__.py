# -*- coding: utf-8 -*-
from . import res_users
from . import ir_config_parameter
