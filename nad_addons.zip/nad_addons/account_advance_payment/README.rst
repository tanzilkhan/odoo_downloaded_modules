Account Advance Payment
=======================

This module you can help with advance payment of custom and suppliers.

This module adds the fields Account Supplier Advance, Account Customer Advance,
Total Customer Advance and Total Supplier Advance in the view form of the partner.

Also adds the field Transaction Type in the view payments of customs and suppliers.