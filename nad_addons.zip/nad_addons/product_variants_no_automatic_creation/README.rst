Product Variants
================

This module creates a check in categories and an option in product templates,
so that it does not create the product variants when the attributes are
assigned. This is used by those modules that create the product when it is
estrictly necessary.


Credits
=======

Contributors
------------
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciobaeza.com>
* Ana Juaristi <ajuaristio@gmail.com>
