# -*- coding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __openerp__.py file in root directory
##############################################################################
from . import mrp_routing
from . import mrp_production
from . import mrp_bom
from . import mrp_workcenter
from . import mrp_routing_operation
from . import stock_move
from . import res_config
