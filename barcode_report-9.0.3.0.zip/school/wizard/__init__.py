# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import assign_roll_no
import move_standards
import wiz_send_email
import wiz_meeting
