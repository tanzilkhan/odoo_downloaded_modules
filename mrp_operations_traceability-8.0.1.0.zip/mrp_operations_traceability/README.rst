Traceability for production operations
======================================

This module allows you to manage the complete traceability of products consumed
in production operations.

You can access the full traceability of a lot from the button "Full
traceability" in the lot form.

The lot, and the final product production, are displayed in the movements of
stock, also you can search and filter by these new fields.

Credits
=======

Contributors
------------
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Daniel Campos <danielcampos@avanzosc.es>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
