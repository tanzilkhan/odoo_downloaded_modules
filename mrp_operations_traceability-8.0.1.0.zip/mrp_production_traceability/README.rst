Traceability for production orders
==================================

This module allows you to manage the complete traceability of products consumed
in production.

To view this complete traceability of a lot, this module shows the "Full
Traceability" button in the form of lots.

The lot, and the final product production, are displayed in the movements of
stock, also you can search and filter by these new fields.

Credits
=======

Contributors
------------
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Daniel Campos <danielcampos@avanzosc.es>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
