r'''
A Django project implementing a web-based user interface for frePPLe.
'''
VERSION = '3.0.1'
