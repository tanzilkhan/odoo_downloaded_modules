
# An empty models file is required to assure the fixtures of this application are detected.
