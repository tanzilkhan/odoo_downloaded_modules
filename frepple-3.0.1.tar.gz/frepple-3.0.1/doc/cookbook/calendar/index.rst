========
Calendar
========

Calendars are used to represent an input that varies over time.
The data element varying over time can be used for various situations: working hours, resource size, safety stock profile, etc...

.. toctree::
   :maxdepth: 1

   working-hours
   calendar-bucket-priority