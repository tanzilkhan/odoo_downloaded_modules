========
Resource
========

Resources represent machines, personnel, or tools.

.. toctree::
   :maxdepth: 1

   resource-type
   resource-skills
   resource-tool
