======================
Changing your password
======================

From the top right of the screen "My Preferences" or from the menu bar a screen can be opened where you can change your password.

An administrator can use the user administration screen to change passwords as well.

.. image:: ../_images/change-password.png
   :alt: Change password
