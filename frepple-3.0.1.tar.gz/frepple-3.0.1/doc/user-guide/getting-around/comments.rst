========
Comments
========

Users can maintain free-text comments on objects.

Existing comments can’t be altered any more once they have been entered.

.. image:: ../_images/comments.png
   :alt: Comments
