==================
Supported browsers
==================

The frePPLe user interface is fully browser based and can be used with
the following web browsers:

* **Google Chrome** 15 and higher.

* **Firefox** 11 and higher.

* | **Internet Explorer** 10 and higher.
  | Make sure NOT to run in “compatibility mode”.

* **Safari** 5 and higher.

* **Opera** 12 and higher.

For best results we recommend a high-resolution and wide screen. The
user interface isn't optimized for mobile devices (yet).
