==========
Unit tests
==========

A series of unit tests is available for the frePPLe user interface.

The page https://docs.djangoproject.com/en/dev/topics/testing/overview/
describes the django testing framework used in frePPLe.

The test suite is run as one of the commands available with in frepplectl.py
script:

::

   frepplectl.py test freppledb

You are encouraged to submit additional test cases to the test suite, wich
is used to validate each new release.
