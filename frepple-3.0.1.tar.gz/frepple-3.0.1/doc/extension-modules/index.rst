=================
Extension modules
=================

FrePPLe can be extended with extension modules - call them "apps" if you want to be trendy.
This chapter describes the modules that are provided with frePPLe.

.. toctree::
   :maxdepth: 2

   odoo-connector
   openbravo-connector
   forecast-module
   inventory-planning-module
   order-quoting-module
   web-service-module
