===============
Other platforms
===============

FrePPLe hasn't been compiled on any other platforms.

If you succeed in porting the code to another platform, please let us know
and give us a hand in updating this document.
