============
Suboperation
============

Suboperations apply to operations of type operation_alternate,
operation_split and operation_routing.

Each of these refer to child-operations.
