# -*- coding: utf-8 -*-
from . import stock
from . import procurement
from . import res_partner
