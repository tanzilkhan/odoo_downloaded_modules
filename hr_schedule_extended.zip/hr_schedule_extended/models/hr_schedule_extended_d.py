from osv import fields, osv
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

class hr_schedule_extended(osv.osv):
    _name = 'hr.schedule.extended'
    _description = 'Employee Schedule Extended'

    def _amount_all_one(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_one_total': 0.0,
            }
            val = ''
            val1=0
            val2=0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.satday_diff.split(':')[0])
                val2+=int(line.satday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_two(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_two_total': 0.0,
            }
            val = ''
            val1=0
            val2=0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.sunday_diff.split(':')[0])
                val2+=int(line.sunday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_three(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_three_total': 0.0,
            }
            val = ''
            val1=0
            val2=0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.monday_diff.split(':')[0])
                val2+=int(line.monday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_four(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_four_total': 0.0,
            }
            val = ''
            val1=0
            val2=0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.tuesday_diff.split(':')[0])
                val2+=int(line.tuesday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_five(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_five_total': 0.0,
            }
            val = ''
            val1=0
            val2=0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.wednesday_diff.split(':')[0])
                val2+=int(line.wednesday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_six(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_six_total': 0.0,
            }
            val = ''
            val1=0
            val2=0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.thursday_diff.split(':')[0])
                val2+=int(line.thursday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res

    def _amount_all_seven(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        for order in self.browse(cr, uid, ids, context=context):
            res[order.id] = {
                'day_seven_total': 0.0,
            }
            val = ''
            val1=0
            val2=0

            for line in order.sche_summary:
                #TODO: calculation
                val1+=int(line.friday_diff.split(':')[0])
                val2+=int(line.friday_diff.split(':')[1])

                hour_adjust = 0
                minute_adjust = 0
                if val2 > 60:
                    minutes_precision = val2/60
                    minutes_fraction = val2 % 60
                    hour_adjust = val1 + abs(minutes_precision)
                    minute_adjust = minutes_fraction
                elif val2 == 60:
                    hour_adjust = val1 + 1
                    minute_adjust = 00
                else:
                    hour_adjust = val1
                    minute_adjust = val2

            val = str(hour_adjust)+':'+str(minute_adjust)
            res[order.id]= val
        return res


    def _get_lines_one(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_two(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_three(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_four(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_five(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_six(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()

    def _get_lines_seven(self, cr, uid, ids, context=None):
        result = {}
        for line in self.pool.get('sche.summary').browse(cr, uid, ids, context=context):
            result[line.sch_rel.id] = True
        return result.keys()


    _columns = {
        'department_id': fields.many2one('hr.department', 'Department Name', required=True,),
        'company_id': fields.many2one('res.company', 'Company',),
        'employee_id': fields.many2one('hr.employee', 'Employee',),
        'template_id': fields.char('Schedule Template', ),
        'date_start': fields.date('Start Date', required=True,),
        'date_end': fields.date('End Date', required=True, ),
        'name': fields.char("Description", size=64, required=True,),
        'sche_summary': fields.one2many('sche.summary', 'sch_rel', 'Work Summary'),

        'day_one_total': fields.function(_amount_all_one, string='Saturday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_one, ['satday_diff'], 10),
            },
            help="Saturday sum"),

        'day_two_total': fields.function(_amount_all_two, string='Sunday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_two, ['sunday_diff'], 10),
            },
            help="Sunday sum"),

        'day_three_total': fields.function(_amount_all_three, string='Monday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_three, ['monday_diff'], 10),
            },
            help="Monday sum"),

        'day_four_total': fields.function(_amount_all_four, string='Tuesday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_four, ['tuesday_diff'], 10),
            },
            help="Tuesday sum"),

        'day_five_total': fields.function(_amount_all_five, string='Wednesday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_five, ['wednesday_diff'], 10),
            },
            help="Wednesday sum"),

        'day_six_total': fields.function(_amount_all_six, string='Thursday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_six, ['thursday_diff'], 10),
            },
            help="Thursday sum"),

        'day_seven_total': fields.function(_amount_all_seven, string='Friday Total',type='char',
            store={
                'hr.schedule.extended': (lambda self, cr, uid, ids, c={}: ids, ['sche_summary'], 10),
                'sche.summary': (_get_lines_seven, ['friday_diff'], 10),
            },
            help="Friday sum"),

        # 'day_one_total': fields.char('Saturday Total'),
        # 'day_two_total': fields.float('Sunday Total'),
        # 'day_three_total': fields.float('Monday Total'),
        # 'day_four_total': fields.float('Tuesday Total'),
        # 'day_five_total': fields.float('Wednesday Total'),
        # 'day_six_total': fields.float('Thursday Total'),
        # 'day_seven_total': fields.float('Friday Total'),
    }

    _defaults = {
        # 'company_id': lambda self, cr, uid, context: self.pool.get('res.company')._company_default_get(cr, uid, 'hr.schedule.extended', context=context),
        # 'state': 'draft',
    }

    def onchange_employee_start_date(self, cr, uid, ids, employee_id, date_start, context=None):

        res = {
            'value': {
                'name': ''
            }
        }
        dStart = False
        edata = False
        if employee_id:
            edata = self.pool.get('hr.employee').read(
                cr, uid, employee_id, ['name', 'contract_id'], context=context)
        if date_start:
            dStart = datetime.strptime(date_start, '%Y-%m-%d').date()
            # The schedule must start on a Monday
            if dStart.weekday() != 0:
                res['value']['date_start'] = False
                res['value']['date_end'] = False
            else:
                dEnd = dStart + relativedelta(days=+6)
                res['value']['date_end'] = dEnd.strftime('%Y-%m-%d')

        if edata['name']:
            res['value']['name'] = edata['name']
            if dStart:
                res['value']['name'] = res['value']['name'] + ': ' + \
                    dStart.strftime('%Y-%m-%d') + ' Wk ' + str(
                        dStart.isocalendar()[1])

        if edata['contract_id']:
            cdata = self.pool.get('hr.contract').read(
                cr, uid, edata['contract_id'][0], ['schedule_template_id'], context=context)
            if cdata['schedule_template_id']:
                res['value']['template_id'] = cdata['schedule_template_id']

        return res

    # def create(self, cr, uid, values, context=None):
    #
    #     res = {}
    #     total_satday_frequency = 'a'
    #     total_satday_hour_frequency = 0
    #     total_satday_minute_frequency = 0
    #     for each_lineitem in values['sche_summary']:
    #         each_lineitem = int(each_lineitem[2]['satday_diff'].split(':')[0])
    #         total_satday_hour_frequency += each_lineitem
    #     for each_lineitem in values['sche_summary']:
    #         each_lineitem = int(each_lineitem[2]['satday_diff'].split(':')[1])
    #         total_satday_minute_frequency += each_lineitem
    #     total_satday_frequency = str(total_satday_hour_frequency)+':'+str(total_satday_minute_frequency)
    #
    #     values['day_one_total']=str(total_satday_frequency)
    #
    #     # res['value'] = {'day_one_total':str(total_satday_frequency),}
    #                     # 'day_two_total':total_sunday_frequency,
    #                     # 'day_three_total':total_monday_frequency,'day_four_total':total_tuesday_frequency,
    #                     # 'day_five_total':total_wednesday_frequency,'day_six_total':total_thursday_frequency,
    #                     # 'day_seven_total':total_friday_frequency,}
    #
    #     return super(hr_schedule_extended, self).create(cr, uid, values, context=context)
    #
    # def write(self, cr, uid, ids, values, context=None):
    #     if values['sche_summary'][0][2]['satday_diff']:
    #         total_satday_hour_frequency = 0
    #         total_satday_minute_frequency = 0
    #         for each_lineitem in values['sche_summary']:
    #             each_lineitem = int(each_lineitem[2]['satday_diff'].split(':')[0])
    #             total_satday_hour_frequency += each_lineitem
    #         for each_lineitem in values['sche_summary']:
    #             each_lineitem = int(each_lineitem[2]['satday_diff'].split(':')[1])
    #             total_satday_minute_frequency += each_lineitem
    #         total_satday_frequency = str(total_satday_hour_frequency)+':'+str(total_satday_minute_frequency)
    #
    #         values['day_one_total']=str(total_satday_frequency)
    #         return super(hr_schedule_extended, self).write(cr, uid, ids, values, context=context)


class sche_summary(osv.osv):
    _name = 'sche.summary'
    _columns = {
        'sch_rel':fields.many2one('hr.schedule.extended'),
        'name': fields.char('Schedule Summary'),
        'employee_name': fields.many2one('hr.employee', 'Employee Name'),

        'satday_one': fields.char('Saturday'),
        'satday_diff': fields.char('Sat Dif'),

        'sunday_one': fields.char('Sunday'),
        'sunday_diff': fields.char('Sun Dif'),

        'monday_one': fields.char('Monday'),
        'monday_diff': fields.char('Mon Dif'),

        'tuesday_one': fields.char('Tuesday'),
        'tuesday_diff': fields.char('tu Dif'),

        'wednesday_one': fields.char('Wednesday'),
        'wednesday_diff': fields.char('wed Dif'),

        'thursday_one': fields.char('Thursday'),
        'thursday_diff': fields.char('thurs Dif'),

        'friday_one': fields.char('Friday'),
        'friday_diff': fields.char('Fri Dif'),

        'total_diff': fields.char('Total'),

    }

    _defaults = {
        'satday_one': '00:00-00:00',
        'sunday_one': '00:00-00:00',
        'monday_one': '00:00-00:00',
        'tuesday_one': '00:00-00:00',
        'wednesday_one': '00:00-00:00',
        'thursday_one': '00:00-00:00',
        'friday_one': '00:00-00:00',

        'satday_diff': '0:0',
        'sunday_diff': '0:0',
        'monday_diff': '0:0',
        'tuesday_diff': '0:0',
        'wednesday_diff': '0:0',
        'thursday_diff': '0:0',
        'friday_diff': '0:0',
    }

    def onchange_saturday_date(self, cr, uid, ids, satday_one, context=None):
        result = {}
        time = satday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'satday_diff': the_diff}

        return result

    def onchange_sunday_date(self, cr, uid, ids, sunday_one, context=None):
        result = {}
        time = sunday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'sunday_diff': the_diff}

        return result

    def onchange_monday_date(self, cr, uid, ids, monday_one, context=None):
        result = {}
        time = monday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'monday_diff': the_diff}

        return result

    def onchange_tuesday_date(self, cr, uid, ids, tuesday_one, context=None):
        result = {}
        time = tuesday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'tuesday_diff': the_diff}

        return result

    def onchange_wednesday_date(self, cr, uid, ids, wednesday_one, context=None):
        result = {}
        time = wednesday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'wednesday_diff': the_diff}

        return result

    def onchange_thursday_date(self, cr, uid, ids, thursday_one, context=None):
        result = {}
        time = thursday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if minute_diff<0:
            minute_diff = minute_diff + 60

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'thursday_diff': the_diff}

        return result

    def onchange_friday_date(self, cr, uid, ids, friday_one, context=None):
        result = {}
        time = friday_one
        if time[1] == ':':
            hour_one = int(time[0])
            minute_one = int(time[2:4])
        else:
            hour_one = int(time[:2])
            minute_one = int(time[3:5])

        if time[7] == ':':
            if time[5] == '-':
                hour_two = int(time[6])
            else:
                hour_two = int(time[5:7])
            minute_two = int(time[8:])
        elif time[6] == ':':
            hour_two = int(time[5])
            minute_two = int(time[7:])
        else:
            hour_two = int(time[6:8])
            minute_two = int(time[9:])

        hour_diff = hour_two - hour_one
        minute_diff = minute_two - minute_one

        if hour_diff < 0:
            hour_diff = hour_diff + 24

        if minute_diff<0:
            minute_diff = minute_diff + 60

        the_diff = str(hour_diff) + ':' + str(minute_diff)

        result['value'] = {'friday_diff': the_diff}

        return result


    def onchange_total_calculation(self, cr, uid, ids, satday_diff, sunday_diff, monday_diff, tuesday_diff, wednesday_diff, thursday_diff, friday_diff, context=None):
        result = {}
        satday_v = satday_diff
        sunday_v = sunday_diff
        monday_v = monday_diff
        tuesday_v = tuesday_diff
        wednesday_v = wednesday_diff
        thursday_v = thursday_diff
        friday_v = friday_diff

        satday_hours = 0
        satday_minutes = 0
        if satday_v[1]==':':
            satday_hours= int(satday_v[0])
            satday_minutes = int(satday_v[2:])
        elif satday_v[2]==':':
            satday_hours = int(satday_v[:2])
            satday_minutes = int(satday_v[3:])

        sunday_hours = 0
        sunday_minutes = 0
        if sunday_v[1]==':':
            sunday_hours= int(sunday_v[0])
            sunday_minutes = int(sunday_v[2:])
        elif sunday_v[2]==':':
            sunday_hours = int(sunday_v[:2])
            sunday_minutes = int(sunday_v[3:])

        monday_hours = 0
        monday_minutes = 0
        if monday_v[1]==':':
            monday_hours= int(monday_v[0])
            monday_minutes = int(monday_v[2:])
        elif monday_v[2]==':':
            monday_hours = int(monday_v[:2])
            monday_minutes = int(monday_v[3:])

        tuesday_hours = 0
        tuesday_minutes = 0
        if tuesday_v[1]==':':
            tuesday_hours= int(tuesday_v[0])
            tuesday_minutes = int(tuesday_v[2:])
        elif tuesday_v[2]==':':
            tuesday_hours = int(tuesday_v[:2])
            tuesday_minutes = int(tuesday_v[3:])

        wednesday_hours = 0
        wednesday_minutes = 0
        if wednesday_v[1]==':':
            wednesday_hours= int(wednesday_v[0])
            wednesday_minutes = int(wednesday_v[2:])
        elif wednesday_v[2]==':':
            wednesday_hours = int(wednesday_v[:2])
            wednesday_minutes = int(wednesday_v[3:])

        thursday_hours = 0
        thursday_minutes = 0
        if thursday_v[1]==':':
            thursday_hours= int(thursday_v[0])
            thursday_minutes = int(thursday_v[2:])
        elif thursday_v[2]==':':
            thursday_hours = int(thursday_v[:2])
            thursday_minutes = int(thursday_v[3:])

        friday_hours = 0
        friday_minutes = 0
        if friday_v[1]==':':
            friday_hours= int(friday_v[0])
            friday_minutes = int(friday_v[2:])
        elif friday_v[2]==':':
            friday_hours = int(friday_v[0:2])
            friday_minutes = int(friday_v[3:5])

        total_hours = satday_hours + sunday_hours + monday_hours + tuesday_hours + wednesday_hours + thursday_hours + friday_hours

        total_minutes = satday_minutes + sunday_minutes + monday_minutes + tuesday_minutes + wednesday_minutes + thursday_minutes + friday_minutes

        hour_adjust = 0
        minute_adjust = 0
        if total_minutes > 60:
            minutes_precision = total_minutes/60
            minutes_fraction = total_minutes % 60
            hour_adjust = total_hours + abs(minutes_precision)
            minute_adjust = minutes_fraction
        elif total_minutes == 60:
            hour_adjust = total_hours + 1
            minute_adjust = 00
        else:
            hour_adjust = total_hours
            minute_adjust = total_minutes

        total_diff_calc = str(hour_adjust)+':'+str(minute_adjust)

        result['value'] = {'total_diff': total_diff_calc}

        return result

