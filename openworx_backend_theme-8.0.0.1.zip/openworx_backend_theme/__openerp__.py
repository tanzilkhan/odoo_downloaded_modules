{
    'name' : 'Openworx Backend Theme',
    'version' : '0.1',
    'author' : 'Openworx',
    'category' : 'Tools',
    'website' : 'http://www.openworx.nl',
    'description': """
Give Odoo 8.0 backend a v9 enterprise look&feel.
    """,
    'depends' : ['base'],
    'data':[
        'views.xml',
        ],
    'installable': True
}
