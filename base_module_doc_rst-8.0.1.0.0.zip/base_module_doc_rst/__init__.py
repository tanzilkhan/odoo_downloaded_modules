# -*- coding: utf-8 -*-
# © 2004-2009 Tiny SPRL <http://tiny.be> (original author)
#
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import base_module_doc_rst
from . import wizard
from . import report
