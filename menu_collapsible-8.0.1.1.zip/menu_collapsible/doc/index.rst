This module makes all menus collapsible for all users.

No configuration is needed.

|

**Contact us:**

When you have any remark about this module, please let us know on http://www.onestein.eu/feedback
