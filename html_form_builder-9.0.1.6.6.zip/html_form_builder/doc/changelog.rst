v1.6.6
======
* Add date picker input

v1.6.5
======
* Change required to required="required"
* remove required from radio group
* remove display_name because it creates confusion since it has the same label as name

v1.6.4
======
* Add dropbox(m2o) to backend form creation

v1.6.3
======
* Add checkbox and radiobutton to backend form creation

v1.6.2
======
* Add dropbox to backend form creation

v1.6.1
======
* Add sequence handle to fields so you can rearrange via backend

v1.6
====
* Add Character Limit

v1.4
====
* Add checkbox(Boolean) input


v1.3
====
* Add 2 fields types, dropbox(many2one) and radio button group(selection)

v1.1
====
* Added Submit action feature

v1.0
====
* Initial Release