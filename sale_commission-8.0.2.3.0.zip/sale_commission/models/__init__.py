# -*- coding: utf-8 -*-
# © 2011 Pexego Sistemas Informáticos (<http://www.pexego.es>)
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import product_template
from . import sale_commission
from . import res_partner
from . import sale_order
from . import account_invoice
from . import settlement
