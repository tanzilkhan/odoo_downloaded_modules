from openerp.osv import osv, fields, orm


class esq_export_lc_delivery_report(osv.Model):

    _name='esq.export.lc.delivery.report'


    def _populate_commercial_invoice_no(self,cr,uid,context=None):
        sql = "SELECT commercial_invoice_no,commercial_invoice_no FROM esq_export_register WHERE commercial_invoice_no IS NOT NULL ORDER BY commercial_invoice_no"
        cr.execute(sql)
        res = cr.fetchall()
        return res

    def onchange_com_inv_no(self,cr,uid,ids,commercial_invoice_no,context=None):
        result = {}
        if commercial_invoice_no is not False:
            commercial_invoice_no_get=self.pool.get('esq.export.register')
            id=commercial_invoice_no_get.search(cr,uid,[('commercial_invoice_no','=',commercial_invoice_no)],context=context)
            if id:
                cm_in_brw=commercial_invoice_no_get.browse(cr,uid,id[0],context=context)
                lc_no=cm_in_brw.lc_no.id
                lc_date=cm_in_brw.lc_date
                lc_issuing_bank=cm_in_brw.issuing_bank
                sales_contract_no=cm_in_brw.sales_contract_no
                commercial_invoice_date=cm_in_brw.commercial_invoice_date

            else:
                lc_no=False
                lc_date=False
                lc_issuing_bank=False
                sales_contract_no=False
                commercial_invoice_date=False

            result['value'] = {'lc_no': lc_no,
                               'lc_date':lc_date,
                               'sales_contract_no':sales_contract_no,
                               'commercial_invoice_date':commercial_invoice_date,
                               'issuing_bank':lc_issuing_bank,
                               }
            return result
        else:
            return result

    _columns={
        'commercial_invoice_no':fields.selection(_populate_commercial_invoice_no,Type='char',string='Commercial Invoice No' ,required=True),
        'commercial_invoice_date':fields.date('Commercial Invoice Date'),
        'lc_no':fields.many2one('esq.export.lc.no','LC No'),
        'lc_date':fields.date('LC Date'),
        'issuing_bank':fields.char('LC Issuing Bank'),
        'sales_contract_no':fields.char('Sales Contract No'),
        'freight':fields.many2one('esq.export.terms.delivery','Freight'),
        'to_customer':fields.many2one('res.partner','To'),
        'esq_export_lc_delivery_pi_rel':fields.one2many('esq.export.lc.delivery.report.pi','delivery_challan_rel','PI Information'),
    }


class esq_export_freight(osv.osv):
    _name = 'esq.export.freight'

    _columns={
        'name':fields.char('Freight')
    }


class esq_export_lc_ci_report_pi(osv.Model):
    _name='esq.export.lc.delivery.report.pi'

    _columns={
        'delivery_challan_rel':fields.many2one('esq.export.lc.ci.report','Commercial Invoice No'),
        'pi_no':fields.char('PI No.'),
        'pi_product':fields.char('Product'),
        'pi_date':fields.date('PI Date'),
        'pi_product_detail':fields.date('Details'),
        'pi_product_quantity':fields.char('Quantity'),
        'pi_product_unit_price':fields.char('Unite Price'),
        'pi_product_price_total':fields.char('Total'),
    }


