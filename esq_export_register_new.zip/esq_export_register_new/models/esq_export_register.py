from openerp.osv import osv, fields, orm
import openerp.tools as tools
from datetime import datetime, timedelta,date
import time
from dateutil.relativedelta import relativedelta


class esq_export_register(osv.Model):
    _name='esq.export.register'

    _rec_name='export_register_no'


    def expo_cal(self, cr, uid, ids, name, arg, context=None):
        res = {}
        # from datetime import timedelta, date
        #
        # d1 = date(2012, 12, 20)
        # print(d1.strftime("%Y %m %d"))
        # d2 = d1 + timedelta(days=3)
        # print(d2.strftime("%Y %m %d"))
        exp_release_date = self.browse(cr,uid,ids,context=context)[0].exp_release_date
        d1=datetime.strptime(exp_release_date,"%Y-%m-%d").date()
        exp120_date=d1 + timedelta(days=120)
        # d2=datetime.strptime(exp120_date,"%Y-%m-%d").date()

        for record in self.browse(cr, uid, ids,context):
            res[record.id] = str(exp120_date)
        return res


    def expo_pending_cal(self, cr, uid, ids, name, arg, context=None):
        res = {}
        date_format = '%Y-%m-%d'
        exp_120_days = self.browse(cr,uid,ids,context=context)[0].exp_120_days
        current_date=datetime.today().strftime(date_format)

        d1 = datetime.strptime(exp_120_days, date_format).date()
        d2= datetime.strptime(current_date, date_format).date()

        pending1= (d1-d2).days
        for record in self.browse(cr, uid, ids,context):
            res[record.id] = pending1
        return res

    def lc_receive_duration(self, cr, uid, ids, name, arg, context=None):
        res = {}
        date_format = '%Y-%m-%d'

        swift_recv_date = self.browse(cr,uid,ids,context=context)[0].swift_recv_date
        lc_copy_receive_date = self.browse(cr,uid,ids,context=context)[0].lc_copy_receive_date

        d1 = datetime.strptime(swift_recv_date, date_format).date()
        d2 = datetime.strptime(lc_copy_receive_date, date_format).date()
        r = d2-d1

        for record in self.browse(cr, uid, ids, context=context):
            res[record.id] = r.days
        return res

    _columns={
        'export_register_no':fields.char('LC Register'),
        'export_category':fields.many2one('esq.export.category','Category'),
        'export_type':fields.selection([('1','BRAIFORM'),('2','License'),('3','Self')],'Export Type'),
        'commercial_invoice_no':fields.char('Commercial Invoice No'),
        'lc_no':fields.many2one('esq.export.lc.no','LC No'),
        'lc_date':fields.date('LC Date'),
        'total_lc_quantity':fields.integer('Total LC Quantity'),
        'total_lc_value':fields.float('Total LC Value'),
        'lc_tenor':fields.many2one('esq.export.lc.tenor','LC Tenor'),
        'shipment_date':fields.date('Shipment Date'),
        'expiry_date':fields.date('Expiry Date'),
        'lc_transfer_date':fields.date('LC Transfer Date'),
        'lc_copy_receive_date':fields.date('LC Copy Receive Date',required='True'),
        'exp_no':fields.integer('EXP No'),
        'exp_release_date':fields.date('EXP Release Date'),
        'exp_120_days':fields.function( expo_cal,type='date',string='EXP-120-Days',readonly=True),
        'pending':fields.function( expo_pending_cal,type='integer',string='Pending',readonly=True),
        'draft_at':fields.selection([('1', '90 days from the date of Acceptance'),('2', '90 days from the date of delivery'),('3', '90 days from the date of negotiation'),('4', '90 days from the date of shipment'),('5', '90 days sight from the date of Acceptance'),('6', '90 days sight from the date of delivery'),('7', '90 days sight from the date of negotiation'),('8', '90 days sight from the date of shipment'),('9', '90 days sight')],'Draft At'),
        'swift_recv_date':fields.date('Swift Receive Date',required='True' ),
        'lc_recv_month':fields.char('Month'),
        'commercial_invoice_date':fields.date('Commercial Invoice Date'),
        'ud_no':fields.integer('UD No'),
        'ud_recv_date':fields.date('UD Receive Date'),
        'status':fields.selection([('1','Advance'),('2','After Delivery')],'Status'),
        'doc_submission_party':fields.date('Document Submission To Party'),
        'acceptance_receive_from_buyer':fields.date('Acceptance Receive From Buyer'),
        'document_submission_received_status':fields.selection([('1','Submit'),('2','Received'),('3','False')],'Document Submission & Received Status'),
        'lc_received_duration_from_bank_advice':fields.function(lc_receive_duration,type='integer',string='LC Received Duration from Bank Advice'),
        'discrepancy_charges':fields.char('Discrepancy Charges'),
        'duration_from_submit':fields.char('Duration From Submit'),
        'Remarks':fields.char('Remarks'),

        'export_pi_info_rel':fields.one2many('esq.export.pi.info','rel_export_pi_info'),

        # bank information

        'issuing_bank':fields.char('Issuing Bank'),
        'ldbc_no':fields.char('LDBC No'),
        'bank_submission_date':fields.date('Bank Submission Date'),
        'pending_date':fields.date('Pending Date'),
        'maturity_date':fields.date('Maturity Date'),
        'actual_receive_date':fields.date('Actual Received Date'),
        'negotiating_bank':fields.char('Negotiating Bank'),
        'remarks':fields.char('Remarks'),

        # ....................

        # document purpose info

        'master_lc_no':fields.char('Master LC No'),
        'master_lc_date':fields.date('Master LC Date'),
        'sales_contract_no':fields.char('Sales Contract No'),
        'sales_contract_date':fields.date('Sales Contract Date'),
        'vat_reg_no':fields.char('Vat Reg No'),
        'hs_code':fields.char('HS Code'),
        'area_code':fields.char('Area Code'),
        'ad_ref_no':fields.char('AD Ref No'),
        'bb_ref_no':fields.char('BB Ref No'),
        'exp_permission_no':fields.char('EXP Permission No'),
        'exp_permission_date':fields.date('EXP Permission Date'),
        'others':fields.char('Others'),
        'lc_application_bin':fields.char('LC Application BIN'),
        'bank_bin_no':fields.char('Bank BIN No'),
        'tin_no':fields.char('TIN No'),
        'irc_no':fields.char('IRC No'),
        'erc_no':fields.char('ERC No'),
        'bond_license_no':fields.char('Bond License No'),

        # .....................
    }


    def create(self, cr, uid, value, context=None ):
        value['export_register_no'] = self.pool.get('ir.sequence').get(cr, uid, 'esq.export.register')

        return super(esq_export_register, self).create(cr, uid, value, context=context)


class esq_export_pi_info(osv.osv):
    _name='esq.export.pi.info'


    def _populate_pi_no(self,cr,uid,context=None):
        sql = "SELECT pi_no,pi_no FROM account_invoice WHERE pi_no IS NOT NULL ORDER BY pi_no"
        cr.execute(sql)
        res = cr.fetchall()
        return res

    def onchange_pi_no(self,cr,uid,ids,pi_no,context=None):
        result = {}
        if pi_no is not False:
            pi_get=self.pool.get('account.invoice')
            id=pi_get.search(cr,uid,[('pi_no','=',pi_no)],context=context)
            if id:
                pi_brw=pi_get.browse(cr,uid,id[0],context=context)
                pi_customer=pi_brw.partner_id.id
                pi_date=pi_brw.date_invoice
                pi_retailer=pi_brw.retailer_name.id
                pi_other_cost=pi_brw.total_other_cost
                # pi_product=pi_brw.invoice_line.name
                # pi_unit_price=pi_brw.price_unit
                pi_price_subtotatal=pi_brw.amount_untaxed
                # pi_quantity=pi_brw.quantity
                pi_total=pi_brw.amount_total
            else:
                pi_customer=False
                pi_unit_price=False
                pi_price_subtotatal=False
                # pi_quantity=False
                pi_date=False
                pi_retailer=False
                pi_total=False
                pi_other_cost=False

            result['value'] = {'customer': pi_customer,
                               # 'sales_rate':pi_unit_price,
                               'buyer_name':pi_retailer,
                               'sales_value':pi_price_subtotatal,
                               # 'pi_quant':pi_quantity,
                               'pi_date':pi_date,
                               'pi_value':pi_total,
                               'other_cost':pi_other_cost

                               }

            return result
        else:
            return result

    _columns={

        'rel_export_pi_info':fields.many2one('esq.export.register'),
        'rel_export_fdd_pi_info':fields.many2one('esq.export.fdd'),
        'rel_export_foreign_tt_pi_info':fields.many2one('esq.export.foreign.tt'),
        'rel_export_local_tt_pi_info':fields.many2one('esq.export.local.tt'),
        'pi_no':fields.selection(_populate_pi_no,Type='char',string='Proforma Invoice No.'),
        'pi_date':fields.date('PI Date'),
        'customer':fields.many2one('res.partner','Customer', required=True, change_default=True, select=True, track_visibility='always'),
        'bayer_name':fields.many2one('retailer.desc','Buyer Name', required=True,change_default=True, select=True, track_visibility='always'),
        'pi_quantity':fields.integer('PI Quantity'),
        'sales_value':fields.float('Sale Values'),
        'other_cost':fields.float('Other Cost'),
        'pi_value':fields.float('PI Total Value'),

    }


class esq_export_lc_amendment(osv.osv):
    _name='esq.export.lc.amendment'

    def _populate_commercial_invoice_no(self,cr,uid,context=None):
        sql = "SELECT commercial_invoice_no,commercial_invoice_no FROM esq_export_register WHERE commercial_invoice_no IS NOT NULL ORDER BY commercial_invoice_no"
        cr.execute(sql)
        res = cr.fetchall()
        return res

    def onchange_com_inv_no(self,cr,uid,ids,commercial_invoice_no,context=None):
        result = {}
        if commercial_invoice_no is not False:
            commercial_invoice_no_get=self.pool.get('esq.export.register')
            id=commercial_invoice_no_get.search(cr,uid,[('commercial_invoice_no','=',commercial_invoice_no)],context=context)
            if id:
                cm_in_brw=commercial_invoice_no_get.browse(cr,uid,id[0],context=context)
                lc_no=cm_in_brw.lc_no.id

            else:
                lc_no=False

            result['value'] = {'lc_no': lc_no,
                               }
            return result
        else:
            return result

    _columns={
        'com_inv_no':fields.selection(_populate_commercial_invoice_no,Type='char',string='Commercial Invoice No' ,required=True),
        'lc_no':fields.many2one('esq.export.lc.no','LC No',required=True),
    }


class esq_export_lc_no(osv.osv):
    _name = 'esq.export.lc.no'

    _columns={
        'name':fields.char('LC No')
    }

class esq_export_lc_tenor(osv.osv):
    _name = 'esq.export.lc.tenor'

    _columns={
        'name':fields.char('LC Tenor')
    }

class esq_export_category(osv.osv):
    _name = 'esq.export.category'

    _columns={
        'name':fields.char('Category')
    }