from openerp.osv import osv, fields, orm
from datetime import datetime, timedelta,date


class esq_export_foreign_tt(osv.Model):
    _name='esq.export.foreign.tt'

    _rec_name='export_foreign_tt_no'

    def expo_cal(self, cr, uid, ids, name, arg, context=None):
        res = {}
        # from datetime import timedelta, date
        #
        # d1 = date(2012, 12, 20)
        # print(d1.strftime("%Y %m %d"))
        # d2 = d1 + timedelta(days=3)
        # print(d2.strftime("%Y %m %d"))
        exp_release_date = self.browse(cr,uid,ids,context=context)[0].exp_release_date
        d1=datetime.strptime(exp_release_date,"%Y-%m-%d").date()
        exp120_date=d1 + timedelta(days=120)
        # d2=datetime.strptime(exp120_date,"%Y-%m-%d").date()

        for record in self.browse(cr, uid, ids,context):
            res[record.id] = str(exp120_date)
        return res


    def expo_pending_cal(self, cr, uid, ids, name, arg, context=None):
        res = {}
        date_format = '%Y-%m-%d'
        exp_120_days = self.browse(cr,uid,ids,context=context)[0].exp_120_days
        current_date=datetime.today().strftime(date_format)

        d1 = datetime.strptime(exp_120_days, date_format).date()
        d2= datetime.strptime(current_date, date_format).date()

        pending1= (d1-d2).days
        for record in self.browse(cr, uid, ids,context):
            res[record.id] = pending1
        return res

    def lc_receive_duration(self, cr, uid, ids, name, arg, context=None):
        res = {}
        date_format = '%Y-%m-%d'

        swift_recv_date = self.browse(cr,uid,ids,context=context)[0].swift_recv_date
        lc_copy_receive_date = self.browse(cr,uid,ids,context=context)[0].lc_copy_receive_date

        d1 = datetime.strptime(swift_recv_date, date_format).date()
        d2 = datetime.strptime(lc_copy_receive_date, date_format).date()
        r = d2-d1

        for record in self.browse(cr, uid, ids, context=context):
            res[record.id] = r.days
        return res

    _columns = {
        'export_foreign_tt_no':fields.char('TT Register'),
        'export_category':fields.many2one('esq.export.category','Category'),
        'commercial_invoice_no':fields.char('Commercial Invoice No'),
        'commercial_invoice_date':fields.date('Commercial Invoice Date'),
        'export_type':fields.selection([('1','BRAIFORM'),('2','License'),('3','Self')],'Export Type'),
        'sc_no':fields.char('SC No'),
        'sc_date':fields.date('SC Date'),
        'foreign_no':fields.char('TT No'),
        'foreign_date':fields.date('TT Date'),
        'total_lc_quantity':fields.integer('Total Goods Quantity'),
        'lc_tenor':fields.many2one('esq.export.lc.tenor','LC Tenor'),
        'shipping_marks':fields.char('Shipping Marks'),
        'lc_recv_month':fields.char('Month'),
        'doc_submission_party':fields.date('Document Submission To Party'),
        'acceptance_receive_from_buyer':fields.date('Acceptance Receive From Buyer'),
        'duration_from_submit':fields.char('Duration From Submit'),
        'discrepancy_charges':fields.char('Discrepancy Charges'),
        'sc_value':fields.float('SC Value'),
        'shipment_date':fields.date('Shipment Date'),
        'expiry_date':fields.date('Expiry Date'),
        'lc_transfer_date':fields.date('TT Transfer Date'),
        'lc_copy_receive_date':fields.date('TT Copy Receive Date'),
        'swift_recv_date':fields.date('Swift Receive Date'),
        'lc_received_duration_from_bank_advice':fields.function(lc_receive_duration,type='integer',string='TT Received Duration from Bank Advice'),
        'status':fields.selection([('1','Advance'),('2','After Delivery')],'Status'),
        'ud_no':fields.integer('UD No'),
        'ud_recv_date':fields.date('UD Receive Date'),
        'document_submission_received_status':fields.char('Document Submission & Received Status'),
        'exp_no':fields.integer('EXP No'),
        'exp_120_days':fields.function( expo_cal,type='date',string='EXP-120-Days',readonly=True),
        'pending':fields.function( expo_pending_cal,type='integer',string='Pending',readonly=True),
        'shipping_terms':fields.many2one('esq.export.shipping.terms','Shipping Terms'),
        'place_of_loading':fields.many2one('esq.export.place.of.loading','Place Of Loading'),
        'port_of_discharge':fields.many2one('esq.export.port.of.discharge','Port Of Discharge'),


        'export_foreign_tt_pi_info_rel':fields.one2many('esq.export.pi.info','rel_export_foreign_tt_pi_info'),

        # bank information

        'issuing_bank':fields.char('Issuing Bank'),
        'ldbc_no':fields.char('LDBC No'),
        'bank_submission_date':fields.date('Bank Submission Date'),
        'pending_date':fields.date('Pending Date'),
        'maturity_date':fields.date('Maturity Date'),
        'actual_receive_date':fields.date('Actual Received Date'),
        'negotiating_bank':fields.char('Negotiating Bank'),
        'remarks':fields.char('Remarks'),

        # ....................

        # document purpose info

        'master_lc_no':fields.char('Master LC No'),
        'master_lc_date':fields.date('Master LC Date'),
        'sales_contract_no':fields.char('Sales Contract No'),
        'sales_contract_date':fields.date('Sales Contract Date'),
        'vat_reg_no':fields.char('Vat Reg No'),
        'hs_code':fields.char('HS Code'),
        'area_code':fields.char('Area Code'),
        'ad_ref_no':fields.char('AD Ref No'),
        'bb_ref_no':fields.char('BB Ref No'),
        'exp_permission_no':fields.char('EXP Permission No'),
        'exp_permission_date':fields.date('EXP Permission Date'),
        'others':fields.char('Others'),
        'lc_application_bin':fields.char('LC Application BIN'),
        'bank_bin_no':fields.char('Bank BIN No'),
        'tin_no':fields.char('TIN No'),
        'irc_no':fields.char('IRC No'),
        'erc_no':fields.char('ERC No'),
        'bond_license_no':fields.char('Bond License No'),

        # .....................
    }

    def create(self, cr, uid, value, context=None ):
        value['export_foreign_tt_no'] = self.pool.get('ir.sequence').get(cr, uid, 'esq.export.foreign.tt')
        return super(esq_export_foreign_tt, self).create(cr, uid, value, context=context)

