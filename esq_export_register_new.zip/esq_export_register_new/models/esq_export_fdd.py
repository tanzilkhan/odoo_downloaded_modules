from openerp.osv import osv, fields, orm



class esq_export_fdd(osv.Model):
    _name='esq.export.fdd'

    _rec_name='export_fdd_no'


    _columns = {
        'export_fdd_no':fields.char('FDD Register'),
        'export_category':fields.many2one('esq.export.category','Category'),
        'commercial_invoice_no':fields.char('Commercial Invoice No'),
        'commercial_invoice_date':fields.date('Commercial Invoice Date'),
        'export_type':fields.selection([('1','BRAIFORM'),('2','License'),('3','Self')],'Export Type'),
        'sc_no':fields.char('SC No'),
        'sc_date':fields.date('SC Date'),
        'fdd_no':fields.char('FDD No'),
        'fdd_date':fields.date('FDD Date'),
        'total_lc_quantity':fields.integer('Total LC Quantity'),
        'lc_tenor':fields.many2one('esq.export.lc.tenor','LC Tenor'),
        'shipping_marks':fields.char('Shipping Marks'),
        'lc_recv_month':fields.char('Month'),
        'doc_submission_party':fields.date('Document Submission To Party'),
        'acceptance_receive_from_buyer':fields.date('Acceptance Receive From Buyer'),
        'duration_from_submit':fields.char('Duration From Submit'),
        'discrepancy_charges':fields.char('Discrepancy Charges'),
        'sc_value':fields.float('FDD Value'),
        'shipment_date':fields.date('Shipment Date'),
        'expiry_date':fields.date('Expiry Date'),
        'lc_transfer_date':fields.date('FDD Transfer Date'),
        'lc_copy_receive_date':fields.date('FDD Copy Receive Date'),
        'swift_recv_date':fields.date('Swift Receive Date'),
        'lc_received_duration_from_bank_advice':fields.char('FDD Received Duration from Bank Advice'),
        'status':fields.selection([('1','Advance'),('2','After Delivery')],'Status'),
        'ud_no':fields.integer('UD No'),
        'ud_recv_date':fields.date('UD Receive Date'),
        'document_submission_received_status':fields.char('Document Submission & Received Status'),
        'exp_no':fields.integer('EXP No'),
        'exp_120_days':fields.integer('EXP-120-Days'),
        'pending':fields.integer('Pending'),
        'shipping_terms':fields.many2one('esq.export.shipping.terms','Shipping Terms'),
        'place_of_loading':fields.many2one('esq.export.place.of.loading','Place Of Loading'),
        'final_destination':fields.many2one('esq.export.final.destination','Final Destination'),

        'export_fdd_pi_info_rel':fields.one2many('esq.export.pi.info','rel_export_fdd_pi_info'),

        # bank information

        'issuing_bank':fields.char('Issuing Bank'),
        'ldbc_no':fields.char('LDBC No'),
        'bank_submission_date':fields.date('Bank Submission Date'),
        'pending_date':fields.date('Pending Date'),
        'maturity_date':fields.date('Maturity Date'),
        'actual_receive_date':fields.date('Actual Received Date'),
        'negotiating_bank':fields.char('Negotiating Bank'),
        'remarks':fields.char('Remarks'),

        # ....................

        # document purpose info

        'master_lc_no':fields.char('Master LC No'),
        'master_lc_date':fields.date('Master LC Date'),
        'sales_contract_no':fields.char('Sales Contract No'),
        'sales_contract_date':fields.date('Sales Contract Date'),
        'vat_reg_no':fields.char('Vat Reg No'),
        'hs_code':fields.char('HS Code'),
        'area_code':fields.char('Area Code'),
        'ad_ref_no':fields.char('AD Ref No'),
        'bb_ref_no':fields.char('BB Ref No'),
        'exp_permission_no':fields.char('EXP Permission No'),
        'exp_permission_date':fields.date('EXP Permission Date'),
        'others':fields.char('Others'),
        'lc_application_bin':fields.char('LC Application BIN'),
        'bank_bin_no':fields.char('Bank BIN No'),
        'tin_no':fields.char('TIN No'),
        'irc_no':fields.char('IRC No'),
        'erc_no':fields.char('ERC No'),
        'bond_license_no':fields.char('Bond License No'),

        # .....................
    }

    def create(self, cr, uid, value, context=None ):
        value['export_fdd_no'] = self.pool.get('ir.sequence').get(cr, uid, 'esq.export.fdd')
        return super(esq_export_fdd, self).create(cr, uid, value, context=context)


    class esq_export_shipping_terms(osv.osv):
        _name = 'esq.export.shipping.terms'

        _columns={
            'name':fields.char('Shipping Terms')
        }

    class esq_export_place_of_loading(osv.osv):
        _name = 'esq.export.place.of.loading'

        _columns={
            'name':fields.char('Place Of Loading')
        }

    class esq_export_final_destination(osv.osv):
        _name = 'esq.export.final.destination'

        _columns={
            'name':fields.char('Final Destination')
        }