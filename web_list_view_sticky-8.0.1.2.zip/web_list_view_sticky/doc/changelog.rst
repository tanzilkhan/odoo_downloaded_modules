.. _changelog:

Changelog
=========

`Ver 1.2`
---------
 - Fix Bug Horizontal Scroll when resize window
 - Fix Bug Top Property Unidentified