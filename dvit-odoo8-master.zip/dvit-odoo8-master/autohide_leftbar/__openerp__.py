# -*- coding: utf-8 -*-

{
    'name': 'Auto Hide Leftbar',
    'version': '1.0',
        'sequence': 1,
    'category': 'Web',
    'summary': 'Auto Hide Secondary menu using simple CSS',
    'description':"Auto Hide Secondary menu",
    'author': 'Dvit',
    'website': 'https://www.dvit.me',
    'depends': ['web',
                ],
    'data': ['views/webclient_templates.xml'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
