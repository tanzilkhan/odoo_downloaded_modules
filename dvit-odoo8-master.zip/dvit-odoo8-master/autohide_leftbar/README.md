dvit-odoo8
===========

Auto hide left sidebar / menu using CSS in Odoo v8 .
