dvit-odoo8 modules
==================

Install only if you have website installed and want to fix RTL report printing.

For support, Plz contact us: http://dvit.me/