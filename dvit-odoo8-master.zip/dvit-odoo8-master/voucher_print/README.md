dvit-odoo8
============

Module for Odoo8 adds print option to account_voucher.

For support, Plz contact us: http://dvit.me/