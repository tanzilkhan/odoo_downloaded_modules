dvit-odoo8
============

Module for Odoo8 (runs on v.7 also) to show discount details on Invoices:

in Inovice Line: Total Before Discount - Discount Value.

in Invoice: Invoice Total before discount - Discount value.

