dvit-odoo8
===========

OpenERP 7 style for top menus .

For support, Plz contact us: http://dvit.me/