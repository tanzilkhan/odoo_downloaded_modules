dvit-odoo8
============

Module for Odoo8 (may run on v.7) to show discount details on Qoutations/Orders:

in Order Line: Total Before Discount - Discount Value.

in Order: Order Total before discount - Discount value.

This Module Depends (not techincally) on invoice_discount .

You must enable discounts on sale settings.

For support, Plz contact us: http://dvit.me/