dvit-odoo8
===========

Odoo initial payroll for most arabic countries and Saudi Arabia.

For support, Plz contact us: http://dvit.me/


