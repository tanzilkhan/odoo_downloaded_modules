DVIT.me odoo8
=====

Various Odoo8 modules are contributed by DiamondVision DVIT.me http://dvit.me .


This repo includes:

invoice discount: shows more information about line and total discount on invoice

sale discount: same as previous but for sales orders.

report-rtl: based on barsi's report-rtl to print reports in RTL.

web-lang: adds support for language based CSS files to support lang direction and fonts.

Auto Hide Leftbar: will autohide the left menu and will show on hover.

Voucher print: will add print option to customer & supplier payments.

l10n_sa: localiation for Arabic countries and Saudi Arabia initially contains Chart of accounts based on the USA CoAs.

For support, Plz contact us: http://dvit.me/