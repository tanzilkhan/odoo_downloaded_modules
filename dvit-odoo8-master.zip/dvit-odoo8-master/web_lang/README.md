dvit-odoo8
===========

This module ( built for odoo v8, may work on v7 ) adds multi-language CSS files support.

Just like any CMS loads a CSS file for each language that may contain special fonts, colors

and direction styles and attributes.

This is built mainly for Direction and contains arabic - ar_SY - RTL CSS and some style modification.

This also contains a simple English en_US style modification for the interface like v7.


