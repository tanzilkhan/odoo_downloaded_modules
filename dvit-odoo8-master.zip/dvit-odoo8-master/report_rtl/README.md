dvit-odoo8 modules
==================

**Note: If you have website installed you must install report_rtl_website also .**

A very simple and clean module to allow printing reports in RTL.

For support, Plz contact us: http://dvit.me/
