# -*- coding: utf-8 -*-

{
    'name': 'OpenERP 7 style',
    'version': '1.0',
        'sequence': 1,
    'category': 'Web',
    'summary': '',
    'description':"",
    'author': 'Dvit',
    'website': 'https://www.dvit.me',
    'depends': ['web',
                ],
    'data': ['views/webclient_templates.xml'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
