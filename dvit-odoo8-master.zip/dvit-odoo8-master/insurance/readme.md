
Insurance Module by DVIT.
======
**Welcome** to Diamond Vision odoo development repository where we share our work.

## Content
####Insurance & Medical Insurance
This module creates the insurance policy to be applied on a contract including medical insurance, the module contains two salary rules to be added to the salary structer in order to take effect on the payslip.

##New features 
#### (1)  module creates two new tabs on employee contract <br> 
                   *Human Resources--> Contracts --> Insurance & Medical insurance 
####(2) module adds the foloowing salary rules to be added on salary structure
                    *insurance
                    *insurancecompany
                    *Medical insurance
#### Preview
![Screenshot software](https://raw.githubusercontent.com/mohamedsaad306/odoo-docs/master/insurance/static/description/contract_insurance.jpg "New Tabs ")

## Contact
#### Diamond Vision Support:
* Homepage: www.dvit.me
* e-mail: info@dvit.me
* Twitter: [@dvitme](https://twitter.com/dvitme "DVIT on twitter")

![Alt text](http://diamondvision.me/images/yootheme/logo_new_00.png?raw=true "DiamondVision")
