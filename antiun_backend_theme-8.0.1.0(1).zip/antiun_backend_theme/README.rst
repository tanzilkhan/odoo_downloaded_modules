.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License

Antiun Backend theme
=====================

Tema de Antiun para cambiar el aspecto del addon web de Odoo

Credits
=======

Contributors
------------

* Antonio Espinosa <antonioea@antiun.com>
* Daniel Góme-Zurita <danielgz@antiun.com>

