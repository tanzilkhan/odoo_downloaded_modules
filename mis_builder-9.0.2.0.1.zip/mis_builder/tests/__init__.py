# -*- coding: utf-8 -*-
# © 2014-2015 ACSONE SA/NV (<http://acsone.eu>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import test_accounting_none
from . import test_aep
from . import test_aggregate
from . import test_fetch_query
from . import test_mis_report_instance
from . import test_mis_safe_eval
from . import test_render
from . import test_simple_array
from . import test_utc_midnight
