Changelog
=========

Version 0.5.3 -- 2015/06/09
---------------------------

* Fix packaging issues. (#21, #22)

Version 0.5.2 -- 2015/01/23
---------------------------

* Added Latvian localization. (#9)
* Improved Spanish localization. (#10, #13, #14)
* Improved Lithuanian localization. (#12)

Version 0.5.1 -- 2014/03/14
---------------------------

* Added Python 3 support with 2to3. (#3)
* Fixed big numbers in spanish. (#2)
* Fixed bugs in tanslation from 30 to 40 in spanish. (#4)
* Fixed word joining in english. (#8)

Version 0.5.0 -- 2013/05/28
---------------------------

* Created ``num2words`` based on the old ``pynum2word`` project.
