##############################################
#
# ChriCar Beteiligungs- und Beratungs- GmbH
# created 2009-09-19 23:51:03+02
##############################################
import stock_product_by_location

